import { Component, OnInit } from '@angular/core';
import { UtilityService } from './services/utility.service';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'frontend';
  loader:any;

  constructor(private utilityService: UtilityService){}

  ngOnInit(): void {
    // this.utilityService.loader.subscribe(res=>{
    //   this.loader=res;
    // })    
  }






  // sample work
  
  profileForm=new FormGroup({
  })

  buttons=['submit1', 'submit2', 'submit3'];

  onSubmit(event:any){
    console.log(event.target.name);
    event.srcElement.style.backgroundColor='red';
  }  

}
